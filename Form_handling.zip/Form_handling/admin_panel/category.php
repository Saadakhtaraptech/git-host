<?php include "../connection.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Category Form</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-8 mx-auto">

        <div class="form-container">
    <h3 class="text-center">Add Category</h3>

    <!-- FIX: correct action path -->
    <form action="../code.php" method="post" enctype="multipart/form-data">
        <label>Upload Image</label>
        <input type="file" name="images" class="form-control" required>

        <label class="mt-2">Name</label>
        <input type="text" name="name" class="form-control" placeholder="Enter name" required>

        <button type="submit" name="category-btn" class="btn btn-success mt-3 w-100">
            Add Category
        </button>
    </form>
</div>
        </div>
    </div>
</div>


<div class="container mt-4">
    <h3 class="text-center">Data</h3>

    <table class="table table-bordered table-hover text-center">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Image</th>
            <th>Action</th>
        </tr>

        <?php
        // FIX: check query error
        $query = mysqli_query($con , "SELECT * FROM add_category") or die(mysqli_error($con));

        if(mysqli_num_rows($query) > 0){
            while($row = mysqli_fetch_assoc($query)){
        ?>
        <tr>
            <td><?php echo $row['cat_id']; ?></td>
            <td><?php echo $row['cat_name']; ?></td>
            <td>
                <!-- FIX: correct image path -->
                <img src="../<?php echo $row['cat_images']; ?>" height="60">
            </td>
            <td>
                <!-- DELETE BUTTON -->
                <form action="../code.php" method="post" style="display:inline;">
                    <input type="hidden" name="id" value="<?php echo $row['cat_id']; ?>">
                    <button class="btn btn-danger btn-sm" name="delete" mt-5>Delete</button>
                    <button class="btn btn-success btn-sm" name="edit" mt-5>edit</button>
                </form>
            </td>
        </tr>
        <?php 
            }
        } else {
            echo "<tr><td colspan='4'>No Data Found</td></tr>";
        }
        ?>
    </table>
</div>

</body>
</html>
