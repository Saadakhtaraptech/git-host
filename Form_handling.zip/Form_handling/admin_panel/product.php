<?php include "../connection.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Category Form</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-8 mx-auto">

        <div class="form-container">
    <h3 class="text-center">Add Products</h3>

    <form action="../code.php" method="post" enctype="multipart/form-data">

        <label class="mt-2">Product Name</label>
        <input type="text" name="p-name" class="form-control mb-3" placeholder="Enter product name" required>


          <label class="mt-2">Product Description</label>
        <input type="text" name="p-descript" class="form-control mb-3" placeholder="Enter product description" required>

             <label class="mt-2">Product Price</label>
        <input type="text" name="p-price" class="form-control mb-3" placeholder="Enter product Price" required>

          <label class="mt-2">Product Quantity</label>
        <input type="text" name="p-qnty" class="form-control mb-3" placeholder="Enter product quantity" required>

        <label class="mt-2">Product Category</label>
        <select name="cat-id" class="form-control mb-3">
            <option value="" readonly>Select Category</option>
            
            <?php
            $fetch_cat = mysqli_query($con, "SELECT * FROM add_category");

            foreach($fetch_cat as $category){
            ?>
             <option value="<?php echo $category['cat_id'];?>" readonly><?php  echo $category['cat_name'];?></option>
            <?php
            }
            ?>

        </select>

        <label>Upload Image</label>
        <input type="file" name="p-image" class="form-control" required>

    
        <button type="submit" name="add-pro" class="btn btn-success mt-3 w-100">
            Add Product
        </button>
    </form>
</div>
        </div>
    </div>
</div>


<div class="container mt-4">
    <h3 class="text-center">Data</h3>

    <table class="table table-bordered table-hover text-center">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Image</th>
            <th>Action</th>
        </tr>

        <?php
        // FIX: check query error
        $query = mysqli_query($con , "SELECT * FROM add_category") or die(mysqli_error($con));

        if(mysqli_num_rows($query) > 0){
            while($row = mysqli_fetch_assoc($query)){
        ?>
        <tr>
            <td><?php echo $row['cat_id']; ?></td>
            <td><?php echo $row['cat_name']; ?></td>
            <td>
                <!-- FIX: correct image path -->
                <img src="../<?php echo $row['cat_images']; ?>" height="60">
            </td>
            <td>
                <!-- DELETE BUTTON -->
                <form action="../code.php" method="post" style="display:inline;">
                    <input type="hidden" name="id" value="<?php echo $row['cat_id']; ?>">
                    <button class="btn btn-danger btn-sm" name="delete" mt-5>Delete</button>
                    <button class="btn btn-success btn-sm" name="edit" mt-5>edit</button>
                </form>
            </td>
        </tr>
        <?php 
            }
        } else {
            echo "<tr><td colspan='4'>No Data Found</td></tr>";
        }
        ?>
    </table>
</div>

</body>
</html>
